#include<stdio.h>
int main(void){
    int x = 10;
    float x = 10;
    printf("%d",x);
}
// give conflict error
// same varible has 2 data-types
// can be resolved by giveing both var. diff. name