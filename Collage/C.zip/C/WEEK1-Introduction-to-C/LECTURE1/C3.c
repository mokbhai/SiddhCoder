#include<stdio.h>
int main(){
    int age = 18;
    printf("Your age is %d", age);
    return 0;
}