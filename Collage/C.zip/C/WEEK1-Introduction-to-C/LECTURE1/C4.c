#include<stdio.h>
int main(){
    int reg = 12221263;
    char roll[4] = "A32";
    long int contact = 7000209021;
    printf("Roll No.: %s\nReg No.: %d\nContact No.: %d", roll, reg, contact);
    return 0;
}