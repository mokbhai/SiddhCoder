#include<stdio.h>
int main(){
    for(int i=0; i<5; i++){
        printf("*");
    }
    printf("\nRoll No: A32");
    printf("\nReg No: 12221263");
    printf("\nName: Mokshit Jain");
    printf("\nUniversity: LPU");
    printf("\nSection: KOCCK\n");
    for(int i=0; i<5; i++){
        printf("*");
    }

    return 0;
}