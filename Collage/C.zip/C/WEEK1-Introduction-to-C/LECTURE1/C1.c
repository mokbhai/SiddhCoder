#include<stdio.h>
    // # => is a preprocesser directory
    // stdio.h => header file
    // std => standard
    // i => input
    // o => output

int main(){     // int Main funcion  >>> always write return 0 at the end
    printf("First line of C Langage");  // for printing
    printf("\nHello World");
    return 0;
}

// void main2(){   // void Main funcion  >>> never write return 0 at the end
//     printf("Secound line of C Langage");
// }