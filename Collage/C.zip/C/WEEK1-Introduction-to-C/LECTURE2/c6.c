#include<stdio.h>
int main(void){
    char a;
    printf("Enter the char: ");
    scanf("%c", &a);
    printf("Your Char is %c\n",a);
}