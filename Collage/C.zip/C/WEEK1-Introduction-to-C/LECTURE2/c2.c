#include<stdio.h>
int main(void){
    int a = 20;
    float pi = 3.14;
    char alph = 'A';
    double d = 3.8416415;
    printf("%i %f %c %lf\n",a,pi,alph,d);
}