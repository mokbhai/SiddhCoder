#include<stdio.h>
int main(void){
    int a = 20;
    float pi = 3.14;
    char alph = 'A';
    double d = 3.8416415;
    printf("%i \n",a);
    printf("%g\n",pi);
    printf("%c\n",alph);
    printf("%lf\n",d);
}