#include<stdio.h>
int main(void){
    float pi;
    printf("Enter the value of pi: ");
    scanf("%g", &pi);
    printf("Value of pi is %g\n",pi);
}