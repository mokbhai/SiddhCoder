#include<stdio.h>
int main(void){
    long double d;
    printf("Enter the value of double: ");
    scanf("%Lf", &d);
    printf("Value of double is %Lf\n",d);
}