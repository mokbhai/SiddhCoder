#include<stdio.h>
int main(void){
    int a;
    printf("Enter the value of a: ");
    scanf("%i", &a);
    printf("Value of a is %i\n",a);
}