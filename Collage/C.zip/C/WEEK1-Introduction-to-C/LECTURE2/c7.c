#include<stdio.h>
int main(void){
    char a[] = "Mokshit Jain";
    // printf("Enter the value of a: ");
    // scanf("%s", &a);
    printf("Value of a is %s\n",a);
}