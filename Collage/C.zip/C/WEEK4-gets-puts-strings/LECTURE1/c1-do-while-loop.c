// Demonstrating do while loop
#include <stdio.h>
int main(void)
{
    int i = 0;
    do
    {
        printf("Hi\n");
        i++;
    }
    while (i < 5);
}