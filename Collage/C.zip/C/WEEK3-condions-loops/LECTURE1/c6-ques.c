#include<stdio.h>
int main(void)
{
    int x = 0;
    if (x == 1)
    {
        printf("true\n");
        if (x >= 0)
        {
            printf("true");
        }
        else
        {
            printf("no");
        }
    }
}