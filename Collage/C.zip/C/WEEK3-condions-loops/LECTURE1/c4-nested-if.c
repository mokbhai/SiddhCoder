// grade system 3 inputs
// check which number is greater from 3 numbers
#include<stdio.h>

int main(void)
{
    int a, b, c, avg;
    printf("Enter python Marks: ");
    scanf("%i", &a);
    printf("Enter chemistry Marks: ");
    scanf("%i", &b);
    printf("Enter Maths Marks: ");
    scanf("%i", &c);

}