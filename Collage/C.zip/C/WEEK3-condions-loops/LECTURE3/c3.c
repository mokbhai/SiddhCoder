// print lpu 5 times by using while loop
#include <stdio.h>

int main(void)
{
    int i = 5;
    while (i <= 5)
    {
        printf("LPU\n");
    }
    
}