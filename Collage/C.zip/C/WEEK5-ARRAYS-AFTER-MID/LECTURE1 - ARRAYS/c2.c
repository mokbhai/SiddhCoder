// write a program to find even number
#include<stdio.h>
int a[1];
int main(void)
{
    scanf("%d", &a[0]);
    printf("%d",a[0]);
}