#include <stdio.h>

int main(void)
{
    int *p;
    printf("%d", p); // garbage value
}