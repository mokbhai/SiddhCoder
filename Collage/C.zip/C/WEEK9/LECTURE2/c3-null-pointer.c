#include <stdio.h>

int main(void)
{
    int a = 5;
    int *p = NULL;
    printf("%d", p); // 0
}