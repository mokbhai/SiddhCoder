#include <stdio.h>
#include <stdlib.h>

int main()
{
    // // ATOF
    // double d = atof("99.23");
    // printf("%.2lf", d);

    // // ATOI
    // char x[] = "99";
    // int i;
    // i = atoi(x);
    // printf("%d", i);

    // // ATOL
    // long int i;
    // char x[] = "10000000";
    // i = atol(x);
    // printf("%ld", i);

    // // ITOA
    // int a = 123;
    // char str[100];
    // itoa(a, str, 2);
    // printf("\n Binary value:%s", str);
    // itoa(a, str, 10);
    // printf("\n Decimal value:%s", str);
    // itoa(a, str, 16);
    // printf("\n Hexadecimal value:%s", str);
    // itoa(a, str, 8);
    // printf("\n Octal value:%s", str);

    return 0;
}