// Some Special Operators include (,), sizeof(), type
// (,) used as => int a, b, c;
// (sizeof()) used to find how much bytes an variable used.
// (type) used to find data type of variable.
#include<stdio.h>
int main(void)
{
    
}