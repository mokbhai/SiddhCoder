#include<stdio.h>

int main(void)
{
    int i = 3;
    int l = i / -2;
    int k = i % -2;
    printf("%i %i", l, k);
}