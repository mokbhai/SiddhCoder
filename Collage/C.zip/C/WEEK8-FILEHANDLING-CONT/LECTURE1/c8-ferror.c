// used for detecting error in the file whten file read write operation ocurre 
// if value is nonzero then error ocurred otherwise zero value
// ferror(fptr);