// getw -> used to read an integer from file in which the numbers are stored
// int a = getw(fptr);
// putw -> print the number in the file
// putw(a, fptr);
