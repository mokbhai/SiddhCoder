// used to move the file pointer to the begning of the given file
// rewind(fptr)