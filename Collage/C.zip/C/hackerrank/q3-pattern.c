#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

void print(int, int, int);

int main() 
{

    int n, size;
    scanf("%d", &n);
  	// Complete the code to print the pattern.
    size = (n * 2) - 1;
    print(n, n, size);
}

void print(int n, int temp, int size)
{
    
}